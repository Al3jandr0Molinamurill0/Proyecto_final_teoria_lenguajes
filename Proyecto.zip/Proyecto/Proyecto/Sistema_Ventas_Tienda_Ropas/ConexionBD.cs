﻿// ConexionBD.cs
using System.Data.SqlClient;
using System.Windows.Forms; // Required for MessageBox

namespace Sistema_Ventas_Tienda_Ropas
{
    public class ConexionBD
    {
        private SqlConnection conexion;
        private string cadenaConexion = "Data Source=LUISREYES\\SQLEXPRESS;Initial Catalog=TiendaRopa;Integrated Security=True";

        public SqlConnection AbrirConexion()
        {
            try
            {
                conexion = new SqlConnection(cadenaConexion);
                conexion.Open();
                return conexion;
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error al conectar a la base de datos: " + ex.Message, "Error de Conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        public void CerrarConexion()
        {
            if (conexion != null && conexion.State == System.Data.ConnectionState.Open)
            {
                conexion.Close();
            }
        }
    }
}