﻿namespace Sistema_Ventas_Tienda_Ropas
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.btnCliente = new System.Windows.Forms.Button();
            this.btnProducto = new System.Windows.Forms.Button();
            this.btnFormularioReportes = new System.Windows.Forms.Button();
            this.btnFormularioVentas = new System.Windows.Forms.Button();
            this.btnVolverLogin = new System.Windows.Forms.Button();
            this.btnCerrarAplicacion = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(155, 58);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(338, 22);
            this.label3.TabIndex = 16;
            this.label3.Text = "Menu del sistema de tienda de ropa";
            // 
            // btnCliente
            // 
            this.btnCliente.BackColor = System.Drawing.Color.Lavender;
            this.btnCliente.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCliente.Image = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.Hopstarter_Sleek_Xp_Basic_Clients_16;
            this.btnCliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCliente.Location = new System.Drawing.Point(85, 171);
            this.btnCliente.Margin = new System.Windows.Forms.Padding(2);
            this.btnCliente.Name = "btnCliente";
            this.btnCliente.Size = new System.Drawing.Size(178, 28);
            this.btnCliente.TabIndex = 18;
            this.btnCliente.Text = "Cliente";
            this.btnCliente.UseVisualStyleBackColor = false;
            this.btnCliente.Click += new System.EventHandler(this.btnCliente_Click);
            // 
            // btnProducto
            // 
            this.btnProducto.BackColor = System.Drawing.Color.Lavender;
            this.btnProducto.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProducto.Image = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.Inipagi_Business_Economic_Store_16;
            this.btnProducto.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProducto.Location = new System.Drawing.Point(85, 246);
            this.btnProducto.Margin = new System.Windows.Forms.Padding(2);
            this.btnProducto.Name = "btnProducto";
            this.btnProducto.Size = new System.Drawing.Size(178, 28);
            this.btnProducto.TabIndex = 20;
            this.btnProducto.Text = "Producto";
            this.btnProducto.UseVisualStyleBackColor = false;
            this.btnProducto.Click += new System.EventHandler(this.btnProducto_Click);
            // 
            // btnFormularioReportes
            // 
            this.btnFormularioReportes.BackColor = System.Drawing.Color.Lavender;
            this.btnFormularioReportes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFormularioReportes.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFormularioReportes.Image = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.Justicon_Free_Simple_Line_Report_Clip_Board_Medical_Data_Business_16;
            this.btnFormularioReportes.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnFormularioReportes.Location = new System.Drawing.Point(357, 169);
            this.btnFormularioReportes.Margin = new System.Windows.Forms.Padding(2);
            this.btnFormularioReportes.Name = "btnFormularioReportes";
            this.btnFormularioReportes.Size = new System.Drawing.Size(196, 43);
            this.btnFormularioReportes.TabIndex = 24;
            this.btnFormularioReportes.Text = "Formulario de reportes";
            this.btnFormularioReportes.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnFormularioReportes.UseVisualStyleBackColor = false;
            this.btnFormularioReportes.Click += new System.EventHandler(this.btnFormularioReportes_Click);
            // 
            // btnFormularioVentas
            // 
            this.btnFormularioVentas.BackColor = System.Drawing.Color.Lavender;
            this.btnFormularioVentas.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFormularioVentas.Image = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.Custom_Icon_Design_Flatastic_5_Sales_by_payment_method3;
            this.btnFormularioVentas.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFormularioVentas.Location = new System.Drawing.Point(357, 246);
            this.btnFormularioVentas.Margin = new System.Windows.Forms.Padding(2);
            this.btnFormularioVentas.Name = "btnFormularioVentas";
            this.btnFormularioVentas.Size = new System.Drawing.Size(199, 35);
            this.btnFormularioVentas.TabIndex = 22;
            this.btnFormularioVentas.Text = "Formulario de ventas";
            this.btnFormularioVentas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFormularioVentas.UseVisualStyleBackColor = false;
            this.btnFormularioVentas.Click += new System.EventHandler(this.btnFormularioVentas_Click);
            // 
            // btnVolverLogin
            // 
            this.btnVolverLogin.BackColor = System.Drawing.Color.Lavender;
            this.btnVolverLogin.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolverLogin.Image = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.Icons8_Windows_8_Industry_Return_16;
            this.btnVolverLogin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVolverLogin.Location = new System.Drawing.Point(85, 328);
            this.btnVolverLogin.Margin = new System.Windows.Forms.Padding(2);
            this.btnVolverLogin.Name = "btnVolverLogin";
            this.btnVolverLogin.Size = new System.Drawing.Size(178, 28);
            this.btnVolverLogin.TabIndex = 25;
            this.btnVolverLogin.Text = "Volver al login";
            this.btnVolverLogin.UseVisualStyleBackColor = false;
            this.btnVolverLogin.Click += new System.EventHandler(this.btnVolverLogin_Click);
            // 
            // btnCerrarAplicacion
            // 
            this.btnCerrarAplicacion.BackColor = System.Drawing.Color.Lavender;
            this.btnCerrarAplicacion.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrarAplicacion.Image = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.Hopstarter_Button_Button_Close_16;
            this.btnCerrarAplicacion.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCerrarAplicacion.Location = new System.Drawing.Point(357, 328);
            this.btnCerrarAplicacion.Margin = new System.Windows.Forms.Padding(2);
            this.btnCerrarAplicacion.Name = "btnCerrarAplicacion";
            this.btnCerrarAplicacion.Size = new System.Drawing.Size(178, 28);
            this.btnCerrarAplicacion.TabIndex = 26;
            this.btnCerrarAplicacion.Text = "Cerrar aplicacion";
            this.btnCerrarAplicacion.UseVisualStyleBackColor = false;
            this.btnCerrarAplicacion.Click += new System.EventHandler(this.btnCerrarAplicacion_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.BackgroundImage = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.Cami;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(643, 404);
            this.Controls.Add(this.btnCerrarAplicacion);
            this.Controls.Add(this.btnVolverLogin);
            this.Controls.Add(this.btnFormularioReportes);
            this.Controls.Add(this.btnFormularioVentas);
            this.Controls.Add(this.btnProducto);
            this.Controls.Add(this.btnCliente);
            this.Controls.Add(this.label3);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCliente;
        private System.Windows.Forms.Button btnProducto;
        private System.Windows.Forms.Button btnFormularioReportes;
        private System.Windows.Forms.Button btnFormularioVentas;
        private System.Windows.Forms.Button btnVolverLogin;
        private System.Windows.Forms.Button btnCerrarAplicacion;
    }
}