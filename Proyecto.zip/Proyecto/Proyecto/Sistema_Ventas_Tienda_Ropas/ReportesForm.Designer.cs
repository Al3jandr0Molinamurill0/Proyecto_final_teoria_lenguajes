﻿namespace Sistema_Ventas_Tienda_Ropas
{
    partial class ReportesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpFechaReporte = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbBuscarCliente = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dgvResultados = new System.Windows.Forms.DataGridView();
            this.lblTotalGeneral = new System.Windows.Forms.Label();
            this.btnVolverMen = new System.Windows.Forms.Button();
            this.btnVerReporte = new System.Windows.Forms.Button();
            this.btnImprimirPDF = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(246, 24);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(202, 24);
            this.label6.TabIndex = 46;
            this.label6.Text = "Formulario de reportes";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.lista_de_verificacion;
            this.pictureBox4.Location = new System.Drawing.Point(290, 67);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(99, 85);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 47;
            this.pictureBox4.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(94, 173);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 19);
            this.label1.TabIndex = 51;
            this.label1.Text = "Fecha";
            // 
            // dtpFechaReporte
            // 
            this.dtpFechaReporte.Location = new System.Drawing.Point(233, 173);
            this.dtpFechaReporte.Margin = new System.Windows.Forms.Padding(2);
            this.dtpFechaReporte.Name = "dtpFechaReporte";
            this.dtpFechaReporte.Size = new System.Drawing.Size(274, 20);
            this.dtpFechaReporte.TabIndex = 50;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(94, 214);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 19);
            this.label2.TabIndex = 53;
            this.label2.Text = "Buscar cliente";
            // 
            // cmbBuscarCliente
            // 
            this.cmbBuscarCliente.FormattingEnabled = true;
            this.cmbBuscarCliente.Location = new System.Drawing.Point(233, 214);
            this.cmbBuscarCliente.Margin = new System.Windows.Forms.Padding(2);
            this.cmbBuscarCliente.Name = "cmbBuscarCliente";
            this.cmbBuscarCliente.Size = new System.Drawing.Size(274, 21);
            this.cmbBuscarCliente.TabIndex = 52;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(266, 245);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 19);
            this.label4.TabIndex = 55;
            this.label4.Text = "Resultados";
            // 
            // dgvResultados
            // 
            this.dgvResultados.BackgroundColor = System.Drawing.Color.White;
            this.dgvResultados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResultados.Location = new System.Drawing.Point(9, 278);
            this.dgvResultados.Margin = new System.Windows.Forms.Padding(2);
            this.dgvResultados.Name = "dgvResultados";
            this.dgvResultados.RowHeadersWidth = 51;
            this.dgvResultados.RowTemplate.Height = 24;
            this.dgvResultados.Size = new System.Drawing.Size(590, 186);
            this.dgvResultados.TabIndex = 54;
            // 
            // lblTotalGeneral
            // 
            this.lblTotalGeneral.AutoSize = true;
            this.lblTotalGeneral.BackColor = System.Drawing.Color.Transparent;
            this.lblTotalGeneral.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalGeneral.Location = new System.Drawing.Point(54, 477);
            this.lblTotalGeneral.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTotalGeneral.Name = "lblTotalGeneral";
            this.lblTotalGeneral.Size = new System.Drawing.Size(109, 19);
            this.lblTotalGeneral.TabIndex = 56;
            this.lblTotalGeneral.Text = "Total General\t";
            this.lblTotalGeneral.Click += new System.EventHandler(this.label3_Click);
            // 
            // btnVolverMen
            // 
            this.btnVolverMen.BackColor = System.Drawing.Color.Lavender;
            this.btnVolverMen.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolverMen.Image = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.Icons8_Windows_8_Industry_Return_16;
            this.btnVolverMen.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVolverMen.Location = new System.Drawing.Point(416, 512);
            this.btnVolverMen.Margin = new System.Windows.Forms.Padding(2);
            this.btnVolverMen.Name = "btnVolverMen";
            this.btnVolverMen.Size = new System.Drawing.Size(160, 28);
            this.btnVolverMen.TabIndex = 59;
            this.btnVolverMen.Text = "Volver al menu";
            this.btnVolverMen.UseVisualStyleBackColor = false;
            this.btnVolverMen.Click += new System.EventHandler(this.btnVolverMen_Click);
            // 
            // btnVerReporte
            // 
            this.btnVerReporte.BackColor = System.Drawing.Color.Lavender;
            this.btnVerReporte.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerReporte.Image = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.Custom_Icon_Design_Flatastic_5_Sales_by_payment_method_16;
            this.btnVerReporte.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVerReporte.Location = new System.Drawing.Point(84, 512);
            this.btnVerReporte.Margin = new System.Windows.Forms.Padding(2);
            this.btnVerReporte.Name = "btnVerReporte";
            this.btnVerReporte.Size = new System.Drawing.Size(150, 28);
            this.btnVerReporte.TabIndex = 58;
            this.btnVerReporte.Text = "Ver reporte";
            this.btnVerReporte.UseVisualStyleBackColor = false;
            this.btnVerReporte.Click += new System.EventHandler(this.btnVerReporte_Click);
            // 
            // btnImprimirPDF
            // 
            this.btnImprimirPDF.BackColor = System.Drawing.Color.Lavender;
            this.btnImprimirPDF.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImprimirPDF.Image = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.Custom_Icon_Design_Flatastic_5_Sales_by_payment_method_16;
            this.btnImprimirPDF.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnImprimirPDF.Location = new System.Drawing.Point(250, 555);
            this.btnImprimirPDF.Margin = new System.Windows.Forms.Padding(2);
            this.btnImprimirPDF.Name = "btnImprimirPDF";
            this.btnImprimirPDF.Size = new System.Drawing.Size(150, 28);
            this.btnImprimirPDF.TabIndex = 60;
            this.btnImprimirPDF.Text = "Imprimir PDF";
            this.btnImprimirPDF.UseVisualStyleBackColor = false;
            this.btnImprimirPDF.Click += new System.EventHandler(this.btnImprimirPDF_Click_1);
            // 
            // ReportesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.BackgroundImage = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.baf477e19bfa9bdba9e14d8b79e74088;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(600, 609);
            this.Controls.Add(this.btnImprimirPDF);
            this.Controls.Add(this.btnVolverMen);
            this.Controls.Add(this.btnVerReporte);
            this.Controls.Add(this.lblTotalGeneral);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dgvResultados);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbBuscarCliente);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpFechaReporte);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label6);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ReportesForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ReportesForm";
            this.Load += new System.EventHandler(this.ReportesForm_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpFechaReporte;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbBuscarCliente;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dgvResultados;
        private System.Windows.Forms.Label lblTotalGeneral;
        private System.Windows.Forms.Button btnVolverMen;
        private System.Windows.Forms.Button btnVerReporte;
        private System.Windows.Forms.Button btnImprimirPDF;
    }
}