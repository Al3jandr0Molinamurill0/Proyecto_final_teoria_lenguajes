﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Sistema_Ventas_Tienda_Ropas
{
    public partial class Registrar_usuarios : Form
    {
        // Instancia de la clase de conexión a la base de datos
        private ConexionBD conexion = new ConexionBD();

        public Registrar_usuarios()
        {
            InitializeComponent();
            // Oculta los caracteres de la contraseña para mayor seguridad
            txtRegistrarContrasena.UseSystemPasswordChar = true;
            txtConfirmarContrasena.UseSystemPasswordChar = true;
        }

        private void btnRegistrarUsuario_Click(object sender, EventArgs e)
        {
           // Paso 2: Obtener los valores ingresados por el usuario
            string nombreUsuario = txtNombreCompleto.Text.Trim(); // .Trim() para eliminar espacios en blanco al inicio/final
            string confirmarNombre = txtConfirmarNombre.Text.Trim();
            string contrasena = txtRegistrarContrasena.Text;
            string confirmarContrasena = txtConfirmarContrasena.Text;

            // Paso 3: Validaciones iniciales de los campos
            if (string.IsNullOrEmpty(nombreUsuario) || string.IsNullOrEmpty(confirmarNombre) ||
                string.IsNullOrEmpty(contrasena) || string.IsNullOrEmpty(confirmarContrasena))
            {
                MessageBox.Show("Por favor, complete todos los campos.", "Campos Vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Detiene la ejecución si hay campos vacíos
            }

            if (nombreUsuario != confirmarNombre)
            {
                MessageBox.Show("El nombre de usuario y su confirmación no coinciden.", "Error de Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (contrasena != confirmarContrasena)
            {
                MessageBox.Show("Las contraseñas no coinciden. Por favor, verifique.", "Error de Contraseña", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Paso 4: Abrir la conexión a la base de datos
            SqlConnection con = conexion.AbrirConexion();

            if (con != null) // Asegurarse de que la conexión se abrió correctamente
            {
                try
                {
                    // Paso 5: Verificar si el nombre de usuario ya existe
                    string checkUserQuery = "SELECT COUNT(1) FROM Usuarios WHERE NombreUsuario = @nombreUsuario";
                    SqlCommand checkCmd = new SqlCommand(checkUserQuery, con);
                    checkCmd.Parameters.AddWithValue("@nombreUsuario", nombreUsuario);

                    int userCount = (int)checkCmd.ExecuteScalar(); // Ejecuta la consulta y obtiene el resultado

                    if (userCount > 0)
                    {
                        MessageBox.Show("El nombre de usuario '" + nombreUsuario + "' ya existe. Por favor, elija otro.", "Usuario Existente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return; // Detiene la ejecución si el usuario ya existe
                    }

                    // Paso 6: Insertar el nuevo usuario en la tabla Usuarios
                    // Nota de seguridad: En una aplicación real, las contraseñas DEBEN ser hasheadas
                    // antes de ser almacenadas en la base de datos. Esto es solo para fines de demostración.
                    string insertQuery = "INSERT INTO Usuarios (NombreUsuario, Contrasena) VALUES (@nombreUsuario, @contrasena)";
                    SqlCommand cmd = new SqlCommand(insertQuery, con);
                    cmd.Parameters.AddWithValue("@nombreUsuario", nombreUsuario);
                    cmd.Parameters.AddWithValue("@contrasena", contrasena); // ¡RECORDATORIO: HASHING DE CONTRASEÑAS ES CRÍTICO!

                    cmd.ExecuteNonQuery(); // Ejecuta la consulta de inserción

                    // Paso 7: Informar al usuario y limpiar los campos
                    MessageBox.Show("Usuario registrado exitosamente.", "Registro Exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimpiarCampos(); // Llama al método para limpiar los TextBoxes

                    // Paso 8: Regresar al formulario de Login después del registro exitoso
                    Login loginForm = new Login();
                    loginForm.Show();
                    this.Hide(); // Oculta el formulario actual
                }
                catch (SqlException ex)
                {
                    // Manejo de errores específicos de SQL
                    MessageBox.Show("Error de base de datos al registrar usuario: " + ex.Message, "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    // Manejo de otros errores generales
                    MessageBox.Show("Ocurrió un error al intentar registrar el usuario: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    // Paso 9: Cerrar la conexión a la base de datos
                    conexion.CerrarConexion();
                }
            } 
        }

        private void LimpiarCampos()
        {
            throw new NotImplementedException();
        }

        private void btnVolverLogin_Click(object sender, EventArgs e)
        {
            // Cierra este formulario y muestra el de login
            Login loginForm = new Login();
            loginForm.Show();
            this.Close();
        }
    }
}
