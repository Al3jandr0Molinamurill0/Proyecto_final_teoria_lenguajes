﻿using System;
using System.Data; // Necesario para DataTable y SqlDataAdapter
using System.Data.SqlClient; // Necesario para SqlConnection, SqlCommand
using System.Windows.Forms; // Necesario para Form, MessageBox, DataGridView

namespace Sistema_Ventas_Tienda_Ropas
{
    public partial class ClienteForm : Form
    {
        // Instancia de la clase de conexión a la base de datos
        private ConexionBD conexion = new ConexionBD();
        public ClienteForm()
        {
            InitializeComponent();
            LoadClients(); // Cargar los clientes al iniciar el formulario
            // Configurar el DataGridView para que los encabezados de columna no permitan ordenación
            foreach (DataGridViewColumn col in dgvClientes.Columns)
            {
                col.SortMode = DataGridViewColumnSortMode.NotSortable;
            }

        }

        private void LoadClients()
        {
            SqlConnection con = conexion.AbrirConexion();
            if (con != null)
            {
                try
                {
                    string query = "SELECT IdCliente, NombreCompleto, Telefono, Direccion, CorreoElectronico FROM Clientes";
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt); // Rellenar el DataTable con los datos de la consulta
                    dgvClientes.DataSource = dt; // Asignar el DataTable como fuente de datos del DataGridView

                   
                    dgvClientes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error al cargar clientes desde la base de datos: " + ex.Message, "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrió un error al cargar los clientes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conexion.CerrarConexion(); // Asegurarse de cerrar la conexión
                }
            }
        }
        // Paso 2: Limpiar los campos de entrada
        private void ClearFields()
        {
            txtIdCliente.Clear();
            txtNombreCompleto.Clear();
            txtTelefono.Clear();
            txtDireccion.Clear();
            txtCorreo.Clear();
            txtIdCliente.ReadOnly = false; // Permitir edición si se va a registrar uno nuevo
            dgvClientes.ClearSelection(); // Deseleccionar cualquier fila en el DataGridView
        }

        private void btnRegistrarCliente_Click(object sender, EventArgs e)
        {
            // Obtener los valores de los TextBoxes
            string nombre = txtNombreCompleto.Text.Trim();
            string telefono = txtTelefono.Text.Trim();
            string direccion = txtDireccion.Text.Trim();
            string email = txtCorreo.Text.Trim();

            // Validaciones
            if (string.IsNullOrEmpty(nombre))
            {
                MessageBox.Show("El nombre completo del cliente es obligatorio.", "Campos Requeridos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SqlConnection con = conexion.AbrirConexion();
            if (con != null)
            {
                try
                {
                    string query = "INSERT INTO Clientes (NombreCompleto, Telefono, Direccion, CorreoElectronico) VALUES (@nombre, @telefono, @direccion, @email)";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@nombre", nombre);
                    // Usar DBNull.Value para campos opcionales que pueden ser nulos en la BD
                    cmd.Parameters.AddWithValue("@telefono", string.IsNullOrEmpty(telefono) ? (object)DBNull.Value : telefono);
                    cmd.Parameters.AddWithValue("@direccion", string.IsNullOrEmpty(direccion) ? (object)DBNull.Value : direccion);
                    cmd.Parameters.AddWithValue("@email", string.IsNullOrEmpty(email) ? (object)DBNull.Value : email);

                    cmd.ExecuteNonQuery(); // Ejecutar la inserción
                    MessageBox.Show("Cliente registrado exitosamente.", "Registro Exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearFields(); // Limpiar campos después del registro
                    LoadClients(); // Recargar la lista de clientes
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error de base de datos al registrar cliente: " + ex.Message, "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrió un error al registrar cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conexion.CerrarConexion();
                }
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtIdCliente.Text))
            {
                MessageBox.Show("Por favor, seleccione un cliente de la lista para editar.", "Selección Requerida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Obtener valores
            int idCliente = Convert.ToInt32(txtIdCliente.Text);
            string nombre = txtNombreCompleto.Text.Trim();
            string telefono = txtTelefono.Text.Trim();
            string direccion = txtDireccion.Text.Trim();
            string email = txtCorreo.Text.Trim();

            // Validaciones (similar a registrar, pero el ID es clave)
            if (string.IsNullOrEmpty(nombre))
            {
                MessageBox.Show("El nombre completo del cliente es obligatorio.", "Campos Requeridos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SqlConnection con = conexion.AbrirConexion();
            if (con != null)
            {
                try
                {
                    string query = "UPDATE Clientes SET NombreCompleto = @nombre, Telefono = @telefono, Direccion = @direccion, CorreoElectronico = @email WHERE IdCliente = @id";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@nombre", nombre);
                    cmd.Parameters.AddWithValue("@telefono", string.IsNullOrEmpty(telefono) ? (object)DBNull.Value : telefono);
                    cmd.Parameters.AddWithValue("@direccion", string.IsNullOrEmpty(direccion) ? (object)DBNull.Value : direccion);
                    cmd.Parameters.AddWithValue("@email", string.IsNullOrEmpty(email) ? (object)DBNull.Value : email);
                    cmd.Parameters.AddWithValue("@id", idCliente);

                    int rowsAffected = cmd.ExecuteNonQuery(); // Ejecutar la actualización
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Cliente actualizado exitosamente.", "Actualización Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ClearFields();
                        LoadClients();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró el cliente con el ID especificado para actualizar.", "Error de Actualización", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error de base de datos al actualizar cliente: " + ex.Message, "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrió un error al actualizar cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conexion.CerrarConexion();
                }
            }
        }

        // Paso 5: Manejar el evento Click del botón "Eliminar"
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtIdCliente.Text))
            {
                MessageBox.Show("Por favor, seleccione un cliente de la lista para eliminar.", "Selección Requerida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Confirmación antes de eliminar
            if (MessageBox.Show("¿Está seguro de que desea eliminar este cliente?", "Confirmar Eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                int idCliente = Convert.ToInt32(txtIdCliente.Text);

                SqlConnection con = conexion.AbrirConexion();
                if (con != null)
                {
                    try
                    {
                        string query = "DELETE FROM Clientes WHERE IdCliente = @id";
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.Parameters.AddWithValue("@id", idCliente);

                        int rowsAffected = cmd.ExecuteNonQuery(); // Ejecutar la eliminación
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Cliente eliminado exitosamente.", "Eliminación Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearFields();
                            LoadClients();
                        }
                        else
                        {
                            MessageBox.Show("No se encontró el cliente con el ID especificado para eliminar.", "Error de Eliminación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show("Error de base de datos al eliminar cliente: " + ex.Message, "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ocurrió un error al eliminar cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        conexion.CerrarConexion();
                    }
                }
            }
        }

        // Paso 6: Manejar el evento Click de una celda en el DataGridView para cargar datos en los TextBoxes
        private void dgvClientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Asegurarse de que se hizo clic en una fila válida (no en el encabezado)
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvClientes.Rows[e.RowIndex];

                // Cargar los datos de la fila seleccionada en los TextBoxes
                txtIdCliente.Text = row.Cells["IdCliente"].Value.ToString();
                txtNombreCompleto.Text = row.Cells["NombreCompleto"].Value.ToString();
                txtTelefono.Text = row.Cells["Telefono"].Value.ToString();
                txtDireccion.Text = row.Cells["Direccion"].Value.ToString();
                txtCorreo.Text = row.Cells["CorreoElectronico"].Value.ToString();

                txtIdCliente.ReadOnly = true; // El ID no debe ser editable una vez cargado
            }
        }


        private void btnVolverMenu_Click(object sender, EventArgs e)
        {
          
            this.Close();
        } // Cerrar el formulario actual de Clientes

        private void Cliente_Load(object sender, EventArgs e)
        {

        }
        private void BuscarClientePorId(int idCliente)
        {
            SqlConnection con = conexion.AbrirConexion();
            if (con != null)
            {
                try
                {
                    string query = "SELECT NombreCompleto, Telefono, Direccion, CorreoElectronico FROM Clientes WHERE IdCliente = @idCliente";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@idCliente", idCliente);

                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        // Llenar los campos con los datos encontrados
                        txtNombreCompleto.Text = reader["NombreCompleto"].ToString();
                        txtTelefono.Text = reader["Telefono"].ToString();
                        txtDireccion.Text = reader["Direccion"].ToString();
                        txtCorreo.Text = reader["CorreoElectronico"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró ningún cliente con ese ID.", "Cliente no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        // Opcional: Limpiar los campos si no se encontró el cliente
                        LimpiarCamposCliente();
                    }
                    reader.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error al buscar el cliente: " + ex.Message, "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conexion.CerrarConexion();
                }
            }
        }

        // Método para limpiar los campos del formulario de cliente
        private void LimpiarCamposCliente()
        {
            txtIdCliente.Clear();
            txtNombreCompleto.Clear();
            txtTelefono.Clear();
            txtDireccion.Clear();
            txtCorreo.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtIdCliente.Text))
            {
                MessageBox.Show("Por favor, ingrese el ID del cliente a buscar.", "Campo Vacío", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (int.TryParse(txtIdCliente.Text, out int idCliente))
            {
                BuscarClientePorId(idCliente);
            }
            else
            {
                MessageBox.Show("El ID de cliente debe ser un número válido.", "Entrada Inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
    
}
