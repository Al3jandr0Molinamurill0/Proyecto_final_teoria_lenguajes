﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_Ventas_Tienda_Ropas
{
    public partial class Login : Form
    {
        // Instancia de la clase de conexión a la base de datos
        private ConexionBD conexion = new ConexionBD();
        public Login()
        {
            InitializeComponent();
            // Paso 1: Configurar el TextBox de Contraseña para ocultar caracteres
            txtContrasena.UseSystemPasswordChar = true; // Esto muestra asteriscos o puntos
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            // Paso 3: Obtener los valores ingresados por el usuario
            string nombreUsuario = txtUsuario.Text.Trim(); // Eliminar espacios en blanco
            string contrasena = txtContrasena.Text;

            // Paso 4: Validaciones iniciales
            if (string.IsNullOrEmpty(nombreUsuario) || string.IsNullOrEmpty(contrasena))
            {
                MessageBox.Show("Por favor, ingrese su nombre de usuario y contraseña.", "Campos Vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Detener la ejecución si los campos están vacíos
            }

            // Paso 5: Abrir la conexión a la base de datos
            SqlConnection con = conexion.AbrirConexion();

            if (con != null) // Verificar que la conexión se haya abierto correctamente
            {
                try
                {
                    // Paso 6: Consulta SQL para verificar las credenciales del usuario
                    // Se usa COUNT(1) para verificar si existe una fila con el usuario y contraseña dados.
                    // ¡ADVERTENCIA DE SEGURIDAD!: Las contraseñas en la BD deben estar HASHEADAS.
                    // Esta comparación directa es solo para fines educativos.
                    string query = "SELECT COUNT(1) FROM Usuarios WHERE NombreUsuario = @username AND Contrasena = @password";

                    SqlCommand cmd = new SqlCommand(query, con);
                    // Paso 7: Añadir parámetros para evitar inyección SQL
                    cmd.Parameters.AddWithValue("@username", nombreUsuario);
                    cmd.Parameters.AddWithValue("@password", contrasena); // ¡RECORDATORIO: USAR HASHING DE CONTRASEÑAS!

                    // Paso 8: Ejecutar la consulta y obtener el resultado
                    // ExecuteScalar() devuelve el primer valor de la primera fila.
                    int count = (int)cmd.ExecuteScalar();

                    // Paso 9: Evaluar el resultado de la autenticación
                    if (count == 1) // Si count es 1, significa que se encontró un usuario con esas credenciales
                    {
                        MessageBox.Show("¡Inicio de sesión exitoso!", "Bienvenido", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Paso 10: Navegar al formulario principal (Menu)
                        Menu principalMenu = new Menu(); // Asumiendo que tu formulario de menú se llama 'Menu'
                        principalMenu.Show();
                        this.Hide(); // Ocultar el formulario de Login (no lo cierres si quieres volver a él)
                    }
                    else
                    {
                        MessageBox.Show("Nombre de usuario o contraseña incorrectos.", "Error de Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtContrasena.Clear(); // Limpiar la contraseña para un nuevo intento
                    }
                }
                catch (SqlException ex)
                {
                    // Manejo de errores específicos de la base de datos
                    MessageBox.Show("Error de base de datos al iniciar sesión: " + ex.Message, "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    // Manejo de cualquier otro tipo de error
                    MessageBox.Show("Ocurrió un error inesperado: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    // Paso 11: Cerrar la conexión a la base de datos en cualquier caso
                    conexion.CerrarConexion();
                }
            }
        }

        private void btnRegistrarUsuario_Click(object sender, EventArgs e)
        {
            // Abre el formulario para registrar un nuevo usuario
            Registrar_usuarios registrarForm = new Registrar_usuarios();
            registrarForm.Show();
            this.Hide();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnVolverMenu_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
