﻿using iTextSharp.text; // Necesario para iTextSharp
using iTextSharp.text.pdf; // Necesario para iTextSharp.PdfPTable, etc.
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO; // Necesario para operaciones de archivo
using System.Windows.Forms;
using System.Linq;

namespace Sistema_Ventas_Tienda_Ropas
{
    public partial class ReportesForm : Form
    {
        private ConexionBD conexion = new ConexionBD();
        public ReportesForm()
        {
            InitializeComponent();
            //dtpFechaReporte.Value = DateTime.Today; // Fecha actual por defecto
            LoadClientsComboBox(); // Cargar clientes para el filtro
            InitializeDataGridView(); // Configurar el DataGridView
        }

        // Método para cargar los clientes en el ComboBox 'cmbBuscarCliente'
        private void LoadClientsComboBox()
        {
            SqlConnection con = conexion.AbrirConexion();
            if (con != null)
            {
                try
                {
                    string query = "SELECT IdCliente, NombreCompleto FROM Clientes ORDER BY NombreCompleto";
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // Añadir una opción para "Todos los clientes"
                    DataRow row = dt.NewRow();
                    row["IdCliente"] = DBNull.Value; // O un valor centinela como -1
                    row["NombreCompleto"] = "Todos los Clientes";
                    dt.Rows.InsertAt(row, 0); // Insertar al principio

                    cmbBuscarCliente.DataSource = dt;
                    cmbBuscarCliente.DisplayMember = "NombreCompleto";
                    cmbBuscarCliente.ValueMember = "IdCliente";
                    cmbBuscarCliente.SelectedIndex = 0; // Seleccionar "Todos los Clientes" por defecto
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error al cargar clientes para el reporte: " + ex.Message, "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conexion.CerrarConexion();
                }
            }
        }

        // Método para configurar el DataGridView 'dgvResultados'
        private void InitializeDataGridView()
        {
            dgvResultados.AutoGenerateColumns = false; // Controlamos las columnas manualmente

            // Definir las columnas
            dgvResultados.Columns.Add("IdVenta", "ID Venta");
            dgvResultados.Columns["IdVenta"].DataPropertyName = "IdVenta";

            dgvResultados.Columns.Add("FechaVenta", "Fecha");
            dgvResultados.Columns["FechaVenta"].DataPropertyName = "FechaVenta";
            dgvResultados.Columns["FechaVenta"].DefaultCellStyle.Format = "dd/MM/yyyy"; // Formato de fecha

            dgvResultados.Columns.Add("NombreCliente", "Cliente");
            dgvResultados.Columns["NombreCliente"].DataPropertyName = "NombreCliente";

            dgvResultados.Columns.Add("NombreProducto", "Producto");
            dgvResultados.Columns["NombreProducto"].DataPropertyName = "NombreProducto";

            dgvResultados.Columns.Add("Cantidad", "Cantidad");
            dgvResultados.Columns["Cantidad"].DataPropertyName = "Cantidad";

            dgvResultados.Columns.Add("PrecioUnitario", "P. Unitario");
            dgvResultados.Columns["PrecioUnitario"].DataPropertyName = "PrecioUnitario";
            dgvResultados.Columns["PrecioUnitario"].DefaultCellStyle.Format = "C2"; // Formato de moneda

            dgvResultados.Columns.Add("Subtotal", "Subtotal");
            dgvResultados.Columns["Subtotal"].DataPropertyName = "Subtotal";
            dgvResultados.Columns["Subtotal"].DefaultCellStyle.Format = "C2"; // Formato de moneda

            dgvResultados.Columns.Add("TotalVenta", "Total Venta");
            dgvResultados.Columns["TotalVenta"].DataPropertyName = "TotalVenta";
            dgvResultados.Columns["TotalVenta"].DefaultCellStyle.Format = "C2"; // Formato de moneda

            // Propiedades del DataGridView
            dgvResultados.AllowUserToAddRows = false;
            dgvResultados.AllowUserToDeleteRows = false;
            dgvResultados.ReadOnly = true;
            dgvResultados.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvResultados.MultiSelect = false;
            dgvResultados.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void btnVerReporte_Click(object sender, EventArgs e)
        {
            GenerateReport();
        }

        // Método para generar y mostrar el reporte en el DataGridView
        private void GenerateReport()
        {
            SqlConnection con = conexion.AbrirConexion();
            if (con != null)
            {
                try
                {
                    // Consulta base para obtener detalles de ventas
                    string query = @"
                        SELECT 
                            V.IdVenta,
                            V.FechaVenta,
                            C.NombreCompleto AS NombreCliente,
                            P.NombreProducto,
                            DV.Cantidad,
                            DV.PrecioUnitario,
                            DV.Subtotal,
                            V.Total AS TotalVenta
                        FROM Ventas V
                        INNER JOIN Clientes C ON V.IdCliente = C.IdCliente
                        INNER JOIN DetalleVentas DV ON V.IdVenta = DV.IdVenta
                        INNER JOIN Productos P ON DV.IdProducto = P.IdProducto
                        WHERE CAST(V.FechaVenta AS DATE) = @fechaReporte"; // Filtrar por fecha

                    // Añadir filtro por cliente si se ha seleccionado uno específico
                    if (cmbBuscarCliente.SelectedValue != null && cmbBuscarCliente.SelectedValue != DBNull.Value)
                    {
                        query += " AND V.IdCliente = @idCliente";
                    }

                    query += " ORDER BY V.FechaVenta, V.IdVenta, P.NombreProducto";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@fechaReporte", dtpFechaReporte.Value.Date); // Solo la parte de la fecha

                    if (cmbBuscarCliente.SelectedValue != null && cmbBuscarCliente.SelectedValue != DBNull.Value)
                    {
                        cmd.Parameters.AddWithValue("@idCliente", (int)cmbBuscarCliente.SelectedValue);
                    }

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dtReporte = new DataTable();
                    da.Fill(dtReporte);

                    dgvResultados.DataSource = dtReporte; // Asignar los resultados al DataGridView

                    // Calcular y mostrar el Total General de las ventas mostradas
                    decimal totalGeneral = 0;
                    if (dtReporte.Rows.Count > 0)
                    {
                        // CORRECCIÓN: Agrupar por IdVenta y luego sumar los TotalVenta únicos
                        totalGeneral = dtReporte.AsEnumerable()
                                               .GroupBy(row => row.Field<int>("IdVenta")) // Agrupar por IdVenta
                                               .Select(group => group.First().Field<decimal>("TotalVenta")) // Seleccionar el TotalVenta de la primera fila de cada grupo (ya que es el mismo para toda la venta)
                                               .Sum(); // Sumar estos totales únicos
                    }
                    lblTotalGeneral.Text = $"Total General: {totalGeneral:C2}"; // Mostrar en el Label

                    if (dtReporte.Rows.Count == 0)
                    {
                        MessageBox.Show("No se encontraron ventas para la fecha y/o cliente seleccionados.", "Sin Resultados", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error al generar el reporte: " + ex.Message, "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conexion.CerrarConexion();
                }
            }
        }

   
private void btnVolverMen_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ReportesForm_Load_1(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnImprimirPDF_Click_1(object sender, EventArgs e)
        {
            if (dgvResultados.Rows.Count == 0)
            {
                MessageBox.Show("No hay datos en el reporte para imprimir.", "Sin Datos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Usar SaveFileDialog para que el usuario elija dónde guardar el PDF
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "PDF files (*.pdf)|*.pdf";
            saveFileDialog.Title = "Guardar Reporte de Ventas como PDF";
            saveFileDialog.FileName = $"Reporte_Ventas_{dtpFechaReporte.Value.ToString("yyyyMMdd")}.pdf";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    Document doc = new Document(PageSize.A4, 20, 20, 20, 20); // Márgenes
                    PdfWriter.GetInstance(doc, new FileStream(saveFileDialog.FileName, FileMode.Create));
                    doc.Open();

                    // --- INICIO DE LA CORRECCIÓN CLAVE ---
                    // Crear una instancia de BaseFont para una fuente estándar (Helvetica)
                    // Esta es la forma correcta de referenciar fuentes básicas con iTextSharp
                    BaseFont bf = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);

                    // Definir las fuentes a usar, utilizando la instancia de BaseFont 'bf'
                    Font fontTitle = new Font(bf, 16, (int)iTextSharp.text.Font.BOLD); // O Font.FontStyle.Bold
                    Font fontInfo = new Font(bf, 10, (int)iTextSharp.text.Font.NORMAL); // O Font.FontStyle.Normal
                    Font fontHeader = new Font(bf, 9, (int)iTextSharp.text.Font.BOLD);
                    Font fontCell = new Font(bf, 8, (int)iTextSharp.text.Font.NORMAL);
                    Font fontTotal = new Font(bf, 12, (int)iTextSharp.text.Font.BOLD);
                    // --- FIN DE LA CORRECCIÓN CLAVE ---


                    // Título del documento
                    Paragraph title = new Paragraph("Reporte de Ventas", fontTitle); // Usa la fuente definida
                    title.Alignment = Element.ALIGN_CENTER;
                    doc.Add(title);

                    // Información de fecha y cliente
                    Paragraph info = new Paragraph($"Fecha del Reporte: {dtpFechaReporte.Value.ToString("dd/MM/yyyy")}\nCliente: {cmbBuscarCliente.Text}", fontInfo); // Usa la fuente definida
                    info.Alignment = Element.ALIGN_LEFT;
                    info.SpacingAfter = 10f;
                    doc.Add(info);

                    // Tabla para los datos del DataGridView
                    PdfPTable pdfTable = new PdfPTable(dgvResultados.ColumnCount);
                    pdfTable.WidthPercentage = 100;

                    // Agregar encabezados de columna
                    foreach (DataGridViewColumn column in dgvResultados.Columns)
                    {
                        // Asegúrate de usar 'fontHeader' aquí
                        PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText, fontHeader)); // Usa la fuente definida
                        cell.BackgroundColor = new BaseColor(200, 200, 200);
                        cell.HorizontalAlignment = Element.ALIGN_CENTER;
                        pdfTable.AddCell(cell);
                    }

                    // Agregar filas de datos
                    foreach (DataGridViewRow row in dgvResultados.Rows)
                    {
                        if (row.IsNewRow) continue;

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            string cellValue = cell.Value != null ? cell.Value.ToString() : "";
                            // Asegúrate de usar 'fontCell' aquí
                            pdfTable.AddCell(new Phrase(cellValue, fontCell)); // Usa la fuente definida
                        }
                    }

                    doc.Add(pdfTable);

                    // Agregar el Total General al final del documento
                    // Asegúrate de usar 'fontTotal' aquí
                    Paragraph totalParagraph = new Paragraph(lblTotalGeneral.Text, fontTotal); // Usa la fuente definida
                    totalParagraph.Alignment = Element.ALIGN_RIGHT;
                    totalParagraph.SpacingBefore = 10f;
                    doc.Add(totalParagraph);

                    doc.Close();
                    MessageBox.Show("Reporte PDF generado exitosamente en:\n" + saveFileDialog.FileName, "PDF Generado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al generar el PDF: " + ex.Message, "Error de PDF", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
