﻿using System;
using System.Data; // Necesario para DataTable y SqlDataAdapter
using System.Data.SqlClient; // Necesario para SqlConnection, SqlCommand
using System.Windows.Forms; // Necesario para Form, MessageBox, DataGridView

namespace Sistema_Ventas_Tienda_Ropas
{
    public partial class Producto : Form
    {
        // Instancia de la clase de conexión a la base de datos
        private ConexionBD conexion = new ConexionBD();

        public Producto()
        {
            InitializeComponent();
            LoadProducts(); // Cargar los productos al iniciar el formulario
            // Configurar el DataGridView para que los encabezados de columna no permitan ordenación
            foreach (DataGridViewColumn col in dgvProductos.Columns)
            {
                col.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
        }

        private void LoadProducts()
        {
            SqlConnection con = conexion.AbrirConexion();
            if (con != null)
            {
                try
                {
                    string query = "SELECT IdProducto, NombreProducto, Descripcion, Precio, Stock FROM Productos";
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt); // Rellenar el DataTable con los datos de la consulta
                    dgvProductos.DataSource = dt; // Asignar el DataTable como fuente de datos del DataGridView

                    // Opcional: Ajustar el ancho de las columnas
                    dgvProductos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error al cargar productos desde la base de datos: " + ex.Message, "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrió un error al cargar los productos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conexion.CerrarConexion(); // Asegurarse de cerrar la conexión
                }
            }
        }

        // Método para limpiar los campos de entrada
        private void ClearFields()
        {
            txtIdProducto.Clear();
            txtNombreProducto.Clear();
            txtDescripcion.Clear();
            txtPrecio.Clear();
            txtStock.Clear();
            txtIdProducto.ReadOnly = false; // Permitir edición si se va a agregar uno nuevo
            dgvProductos.ClearSelection(); // Deseleccionar cualquier fila en el DataGridView
        }
      
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            // Obtener los valores de los TextBoxes
            string nombre = txtNombreProducto.Text.Trim();
            string descripcion = txtDescripcion.Text.Trim();
            string precioStr = txtPrecio.Text.Trim();
            string stockStr = txtStock.Text.Trim();

            // Validaciones
            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(precioStr) || string.IsNullOrEmpty(stockStr))
            {
                MessageBox.Show("Los campos Nombre, Precio y Stock son obligatorios.", "Campos Requeridos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(precioStr, out decimal precio))
            {
                MessageBox.Show("Por favor, ingrese un precio válido.", "Error de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(stockStr, out int stock))
            {
                MessageBox.Show("Por favor, ingrese un stock válido.", "Error de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            SqlConnection con = conexion.AbrirConexion();
            if (con != null)
            {
                try
                {
                    string query = "INSERT INTO Productos (NombreProducto, Descripcion, Precio, Stock) VALUES (@nombre, @descripcion, @precio, @stock)";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@nombre", nombre);
                    cmd.Parameters.AddWithValue("@descripcion", string.IsNullOrEmpty(descripcion) ? (object)DBNull.Value : descripcion);
                    cmd.Parameters.AddWithValue("@precio", precio);
                    cmd.Parameters.AddWithValue("@stock", stock);

                    cmd.ExecuteNonQuery(); // Ejecutar la inserción
                    MessageBox.Show("Producto agregado exitosamente.", "Registro Exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearFields(); // Limpiar campos después del registro
                    LoadProducts(); // Recargar la lista de productos
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error de base de datos al agregar producto: " + ex.Message, "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrió un error al agregar producto: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conexion.CerrarConexion();
                }
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtIdProducto.Text))
            {
                MessageBox.Show("Por favor, seleccione un producto de la lista para editar.", "Selección Requerida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Obtener valores
            int idProducto = Convert.ToInt32(txtIdProducto.Text);
            string nombre = txtNombreProducto.Text.Trim();
            string descripcion = txtDescripcion.Text.Trim();
            string precioStr = txtPrecio.Text.Trim();
            string stockStr = txtStock.Text.Trim();

            // Validaciones
            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(precioStr) || string.IsNullOrEmpty(stockStr))
            {
                MessageBox.Show("Los campos Nombre, Precio y Stock son obligatorios.", "Campos Requeridos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(precioStr, out decimal precio))
            {
                MessageBox.Show("Por favor, ingrese un precio válido.", "Error de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(stockStr, out int stock))
            {
                MessageBox.Show("Por favor, ingrese un stock válido.", "Error de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            SqlConnection con = conexion.AbrirConexion();
            if (con != null)
            {
                try
                {
                    string query = "UPDATE Productos SET NombreProducto = @nombre, Descripcion = @descripcion, Precio = @precio, Stock = @stock WHERE IdProducto = @id";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@nombre", nombre);
                    cmd.Parameters.AddWithValue("@descripcion", string.IsNullOrEmpty(descripcion) ? (object)DBNull.Value : descripcion);
                    cmd.Parameters.AddWithValue("@precio", precio);
                    cmd.Parameters.AddWithValue("@stock", stock);
                    cmd.Parameters.AddWithValue("@id", idProducto);

                    int rowsAffected = cmd.ExecuteNonQuery(); // Ejecutar la actualización
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Producto actualizado exitosamente.", "Actualización Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ClearFields();
                        LoadProducts();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró el producto con el ID especificado para actualizar.", "Error de Actualización", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error de base de datos al actualizar producto: " + ex.Message, "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrió un error al actualizar producto: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conexion.CerrarConexion();
                }
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtIdProducto.Text))
            {
                MessageBox.Show("Por favor, seleccione un producto de la lista para eliminar.", "Selección Requerida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Confirmación antes de eliminar
            if (MessageBox.Show("¿Está seguro de que desea eliminar este producto?", "Confirmar Eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                int idProducto = Convert.ToInt32(txtIdProducto.Text);

                SqlConnection con = conexion.AbrirConexion();
                if (con != null)
                {
                    try
                    {
                        string query = "DELETE FROM Productos WHERE IdProducto = @id";
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.Parameters.AddWithValue("@id", idProducto);

                        int rowsAffected = cmd.ExecuteNonQuery(); // Ejecutar la eliminación
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Producto eliminado exitosamente.", "Eliminación Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearFields();
                            LoadProducts();
                        }
                        else
                        {
                            MessageBox.Show("No se encontró el producto con el ID especificado para eliminar.", "Error de Eliminación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show("Error de base de datos al eliminar producto: " + ex.Message, "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ocurrió un error al eliminar producto: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        conexion.CerrarConexion();
                    }
                }
            }
        }

        // Manejar el evento Click de una celda en el DataGridView para cargar datos en los TextBoxes
        private void dgvProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Asegurarse de que se hizo clic en una fila válida (no en el encabezado)
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvProductos.Rows[e.RowIndex];

                // Cargar los datos de la fila seleccionada en los TextBoxes
                txtIdProducto.Text = row.Cells["IdProducto"].Value.ToString();
                txtNombreProducto.Text = row.Cells["NombreProducto"].Value.ToString();
                txtDescripcion.Text = row.Cells["Descripcion"].Value.ToString();
                txtPrecio.Text = row.Cells["Precio"].Value.ToString();
                txtStock.Text = row.Cells["Stock"].Value.ToString();

                txtIdProducto.ReadOnly = true; // El ID no debe ser editable una vez cargado
            }
        }
        private void btnVolverMenu_Click(object sender, EventArgs e)
        {
            this.Close(); // Cerrar el formulario actual de Productos
        }

        private void Producto_Load(object sender, EventArgs e)
        {

        }
        private void txtIdProducto_TextChanged(object sender, EventArgs e)
        {
            // Este método se ejecuta cada vez que el texto en txtIdProducto cambia.
            
        }
        private void BuscarProductoPorId(int idProducto)
        {
            SqlConnection con = conexion.AbrirConexion(); // Abre la conexión a la base de datos
            if (con != null)
            {
                try
                {
                    // Consulta SQL para seleccionar los datos del producto
                    string query = "SELECT NombreProducto, Descripcion, Precio, Stock FROM Productos WHERE IdProducto = @idProducto";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@idProducto", idProducto); // Añade el parámetro para evitar inyección SQL

                    SqlDataReader reader = cmd.ExecuteReader(); // Ejecuta la consulta y obtiene un lector de datos

                    if (reader.Read()) // Si se encuentra una fila (un producto)
                    {
                        // Llenar los campos del formulario con los datos encontrados
                        txtNombreProducto.Text = reader["NombreProducto"].ToString();
                        txtDescripcion.Text = reader["Descripcion"].ToString();
                        txtPrecio.Text = reader["Precio"].ToString();
                        txtStock.Text = reader["Stock"].ToString();
                    }
                    else // Si no se encontró ningún producto con ese ID
                    {
                        MessageBox.Show("No se encontró ningún producto con ese ID.", "Producto no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LimpiarCamposProducto(); // Opcional: Limpiar los campos si no se encontró el producto
                    }
                    reader.Close(); // Es importante cerrar el lector
                }
                catch (SqlException ex)
                {
                    // Captura errores específicos de SQL
                    MessageBox.Show("Error al buscar el producto en la base de datos: " + ex.Message, "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    // Captura cualquier otro tipo de error
                    MessageBox.Show("Ocurrió un error inesperado al buscar el producto: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conexion.CerrarConexion(); // Asegurarse de cerrar la conexión a la BD
                }
            }
        }

        // Método auxiliar para limpiar los campos de entrada del formulario
        private void LimpiarCamposProducto()
        {
            txtIdProducto.Clear();
            txtNombreProducto.Clear();
            txtDescripcion.Clear();
            txtPrecio.Clear();
            txtStock.Clear();
        }



        private void btnBuscarProducto_Click(object sender, EventArgs e)
        {
            // Validar que el campo ID Producto no esté vacío
            if (string.IsNullOrWhiteSpace(txtIdProducto.Text))
            {
                MessageBox.Show("Por favor, ingrese el ID del producto a buscar.", "Campo Vacío", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Intentar convertir el texto del ID a un número entero
            if (int.TryParse(txtIdProducto.Text, out int idProducto))
            {
                // Si la conversión es exitosa, llamar al método de búsqueda
                BuscarProductoPorId(idProducto);
            }
            else
            {
                // Si la conversión falla, mostrar un mensaje de error
                MessageBox.Show("El ID de producto debe ser un número válido.", "Entrada Inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
