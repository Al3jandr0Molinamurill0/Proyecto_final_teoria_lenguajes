﻿// VentasForm.cs
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Linq; // Necesario para .FirstOrDefault() si se usara, pero ya no es estrictamente necesario con los nombres fijos.

namespace Sistema_Ventas_Tienda_Ropas
{
    public partial class VentasForm : Form
    {
        private ConexionBD conexion = new ConexionBD();
        private DataTable dtProductosVenta; // DataTable que servirá como fuente de datos para dgvProductosVenta

        public VentasForm()
        {
            InitializeComponent();

            // Configuración inicial de los controles principales de la venta
            txtIdVenta.ReadOnly = true; // El ID de venta es de solo lectura
            txtTotalPagar.ReadOnly = true; // El total a pagar es de solo lectura
            dateTimePickerFecha.Value = DateTime.Today; // Establecer la fecha actual por defecto

            // Configuración del control de cantidad de producto
            numCantidadProducto.Minimum = 1; // La cantidad mínima a agregar es 1
            numCantidadProducto.Maximum = 9999; // Límite alto para la cantidad

            // Cargar datos en los ComboBoxes y configurar el DataGridView
            LoadClientsComboBox(); // Cargar los clientes en el ComboBox cmbClientes
            LoadProductsComboBox(); // Cargar productos en el ComboBox cmbProductosAgregar
            InitializeProductsDataGridView(); // Configurar las columnas de dgvProductosVenta
        }

        // Método para cargar los clientes en el ComboBox 'cmbClientes'
        private void LoadClientsComboBox()
        {
            SqlConnection con = conexion.AbrirConexion();
            if (con != null)
            {
                try
                {
                    string query = "SELECT IdCliente, NombreCompleto FROM Clientes";
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    cmbClientes.DataSource = dt;
                    cmbClientes.DisplayMember = "NombreCompleto"; // Lo que se muestra al usuario
                    cmbClientes.ValueMember = "IdCliente";       // El valor real (ID) asociado
                    cmbClientes.SelectedIndex = -1; // No seleccionar nada por defecto al inicio
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error al cargar clientes: " + ex.Message, "Error de Base de Datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conexion.CerrarConexion();
                }
            }
        }

        // Método para cargar los productos en el ComboBox 'cmbProductosAgregar'
        private void LoadProductsComboBox()
        {
            SqlConnection con = conexion.AbrirConexion();
            if (con != null)
            {
                try
                {
                    // Seleccionamos IdProducto, NombreProducto, Precio y Stock para poder usarlos al agregar al DataGridView
                    string query = "SELECT IdProducto, NombreProducto, Precio, Stock FROM Productos WHERE Stock > 0"; // Solo productos con stock
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    cmbProductosAgregar.DataSource = dt;
                    cmbProductosAgregar.DisplayMember = "NombreProducto"; // Mostrar el nombre del producto
                    cmbProductosAgregar.ValueMember = "IdProducto";      // Usar el IdProducto como valor
                    cmbProductosAgregar.SelectedIndex = -1; // No seleccionar nada por defecto
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error al cargar productos para la selección: " + ex.Message, "Error de Base de Datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conexion.CerrarConexion();
                }
            }
        }

        // Método para configurar las columnas del DataGridView 'dgvProductosVenta'
        private void InitializeProductsDataGridView()
        {
            dtProductosVenta = new DataTable();
            dtProductosVenta.Columns.Add("IdProducto", typeof(int));
            dtProductosVenta.Columns.Add("NombreProducto", typeof(string));
            dtProductosVenta.Columns.Add("Cantidad", typeof(int));
            dtProductosVenta.Columns.Add("PrecioUnitario", typeof(decimal));
            dtProductosVenta.Columns.Add("Subtotal", typeof(decimal));

            dgvProductosVenta.DataSource = dtProductosVenta; // Asignar el DataTable como fuente del DataGridView

            // Propiedades del DataGridView para mejor usabilidad
            dgvProductosVenta.AllowUserToAddRows = false;    // No permitir al usuario añadir filas directamente
            dgvProductosVenta.AllowUserToDeleteRows = false; // No permitir al usuario eliminar filas directamente
            dgvProductosVenta.ReadOnly = true;               // Hacer que las celdas no sean editables
            dgvProductosVenta.SelectionMode = DataGridViewSelectionMode.FullRowSelect; // Seleccionar fila completa al hacer clic
            dgvProductosVenta.MultiSelect = false;           // Solo permitir seleccionar una fila a la vez

            // Opcional: Ajustar el ancho de las columnas automáticamente
            dgvProductosVenta.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        // Evento Click para el botón 'btnAgregarProductoALista'
        

        // Método para actualizar el TextBox 'txtTotalPagar'
        private void UpdateTotal()
        {
            decimal total = 0;
            foreach (DataRow row in dtProductosVenta.Rows)
            {
                total += Convert.ToDecimal(row["Subtotal"]);
            }
            txtTotalPagar.Text = total.ToString("N2"); // Mostrar el total formateado a 2 decimales
        }

        // Evento Click para el botón 'btnGenerarVenta'
        private void btnGenerarVenta_Click(object sender, EventArgs e)
        {
            // Validaciones antes de generar la venta
            if (cmbClientes.SelectedValue == null)
            {
                MessageBox.Show("Por favor, seleccione un cliente para la venta.", "Cliente Requerido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dtProductosVenta.Rows.Count == 0)
            {
                MessageBox.Show("Por favor, agregue productos a la venta.", "Productos Requeridos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Obtener los datos de la venta
            int idCliente = (int)cmbClientes.SelectedValue;
            DateTime fechaVenta = dateTimePickerFecha.Value;
            decimal totalVenta = Convert.ToDecimal(txtTotalPagar.Text);

            SqlConnection con = conexion.AbrirConexion();
            if (con != null)
            {
                SqlTransaction transaction = null; // Usar una transacción para asegurar la integridad de los datos
                try
                {
                    transaction = con.BeginTransaction(); // Iniciar la transacción

                    // 1. Insertar la Venta en la tabla 'Ventas'
                    string insertVentaQuery = "INSERT INTO Ventas (FechaVenta, IdCliente, Total) VALUES (@fecha, @clienteId, @total); SELECT SCOPE_IDENTITY();";
                    SqlCommand cmdVenta = new SqlCommand(insertVentaQuery, con, transaction);
                    cmdVenta.Parameters.AddWithValue("@fecha", fechaVenta);
                    cmdVenta.Parameters.AddWithValue("@clienteId", idCliente);
                    cmdVenta.Parameters.AddWithValue("@total", totalVenta);

                    // ExecuteScalar devuelve el primer valor de la primera fila, que es el ID generado por IDENTITY
                    int idVenta = Convert.ToInt32(cmdVenta.ExecuteScalar());
                    txtIdVenta.Text = idVenta.ToString(); // Mostrar el ID de la venta generada

                    // 2. Insertar los DetalleVentas y actualizar el Stock de Productos
                    foreach (DataRow row in dtProductosVenta.Rows)
                    {
                        int idProducto = Convert.ToInt32(row["IdProducto"]);
                        int cantidad = Convert.ToInt32(row["Cantidad"]);
                        decimal precioUnitario = Convert.ToDecimal(row["PrecioUnitario"]);
                        decimal subtotal = Convert.ToDecimal(row["Subtotal"]);

                        // Insertar el detalle de la venta en la tabla 'DetalleVentas'
                        string insertDetalleQuery = "INSERT INTO DetalleVentas (IdVenta, IdProducto, Cantidad, PrecioUnitario, Subtotal) VALUES (@idVenta, @idProducto, @cantidad, @precioUnitario, @subtotal)";
                        SqlCommand cmdDetalle = new SqlCommand(insertDetalleQuery, con, transaction);
                        cmdDetalle.Parameters.AddWithValue("@idVenta", idVenta);
                        cmdDetalle.Parameters.AddWithValue("@idProducto", idProducto);
                        cmdDetalle.Parameters.AddWithValue("@cantidad", cantidad);
                        cmdDetalle.Parameters.AddWithValue("@precioUnitario", precioUnitario);
                        cmdDetalle.Parameters.AddWithValue("@subtotal", subtotal);
                        cmdDetalle.ExecuteNonQuery();

                        // Actualizar el Stock del Producto en la tabla 'Productos'
                        string updateStockQuery = "UPDATE Productos SET Stock = Stock - @cantidad WHERE IdProducto = @idProducto AND Stock >= @cantidad";
                        SqlCommand cmdStock = new SqlCommand(updateStockQuery, con, transaction);
                        cmdStock.Parameters.AddWithValue("@cantidad", cantidad);
                        cmdStock.Parameters.AddWithValue("@idProducto", idProducto);
                        int rowsAffectedStock = cmdStock.ExecuteNonQuery();

                        if (rowsAffectedStock == 0)
                        {
                            // Si por alguna razón el stock no se actualizó (ej. otro usuario lo compró), revertir
                            throw new Exception($"Error: Stock insuficiente para el producto '{row["NombreProducto"]}' al finalizar la venta. La venta será revertida.");
                        }
                    }

                    transaction.Commit(); // Confirmar la transacción si todas las operaciones fueron exitosas
                    MessageBox.Show("Venta generada exitosamente.", "Venta Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearSaleForm(); // Limpiar el formulario para una nueva venta
                    LoadProductsComboBox(); // Recargar productos para reflejar el stock actualizado
                }
                catch (Exception ex)
                {
                    if (transaction != null)
                    {
                        transaction.Rollback(); // Revertir todos los cambios si ocurre algún error
                    }
                    MessageBox.Show("Ocurrió un error al generar la venta: " + ex.Message, "Error de Venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conexion.CerrarConexion();
                }
            }
        }

        // Evento Click para el botón 'btnCancelar'
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            ClearSaleForm(); // Limpiar todos los campos del formulario
            MessageBox.Show("Venta cancelada.", "Cancelado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Método para limpiar todos los campos del formulario de venta
        private void ClearSaleForm()
        {
            txtIdVenta.Clear();
            dateTimePickerFecha.Value = DateTime.Today;
            cmbClientes.SelectedIndex = -1; // Deseleccionar cliente
            dtProductosVenta.Clear(); // Limpiar todas las filas del DataGridView
            txtTotalPagar.Text = "0.00";
            cmbProductosAgregar.SelectedIndex = -1; // Deseleccionar producto
            numCantidadProducto.Value = 1;          // Restablecer la cantidad a 1
        }

        // Evento Click para el botón 'btnVolverMenu'
        private void btnVolverMenu_Click(object sender, EventArgs e)
        {         
            this.Close(); // Cerrar el formulario actual de Ventas
        }

        private void btnAgregarProductoALista_Click_1(object sender, EventArgs e)
        {
            // Validar que se ha seleccionado un producto
            if (cmbProductosAgregar.SelectedValue == null)
            {
                MessageBox.Show("Por favor, seleccione un producto para agregar.", "Producto No Seleccionado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int idProducto = (int)cmbProductosAgregar.SelectedValue;
            string nombreProducto = cmbProductosAgregar.Text;
            int cantidad = (int)numCantidadProducto.Value; // Cantidad seleccionada en el NumericUpDown

            // Obtener el precio y stock actual del producto desde el origen de datos del ComboBox
            // Esto evita una nueva consulta a la BD y es más eficiente.
            DataRowView selectedRowView = cmbProductosAgregar.SelectedItem as DataRowView;
            if (selectedRowView == null)
            {
                MessageBox.Show("Error interno al obtener detalles del producto seleccionado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            decimal precioUnitario = Convert.ToDecimal(selectedRowView["Precio"]);
            int stockDisponible = Convert.ToInt32(selectedRowView["Stock"]);

            // Validar si la cantidad solicitada excede el stock disponible
            if (cantidad > stockDisponible)
            {
                MessageBox.Show($"Stock insuficiente para '{nombreProducto}'. Solo hay {stockDisponible} unidades disponibles.", "Stock Insuficiente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Verificar si el producto ya está en la lista de la venta (dtProductosVenta)
            DataRow[] existingRows = dtProductosVenta.Select($"IdProducto = {idProducto}");

            if (existingRows.Length > 0)
            {
                // Si el producto ya está en la lista, actualizamos la cantidad y el subtotal
                DataRow rowToUpdate = existingRows[0];
                int currentCantidadEnVenta = Convert.ToInt32(rowToUpdate["Cantidad"]);
                int nuevaCantidadEnVenta = currentCantidadEnVenta + cantidad;

                // Volver a validar si la nueva cantidad total excede el stock disponible
                if (nuevaCantidadEnVenta > stockDisponible)
                {
                    MessageBox.Show($"No puedes agregar {cantidad} unidades más de '{nombreProducto}'. Solo quedan {stockDisponible - currentCantidadEnVenta} unidades disponibles.", "Stock Insuficiente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                rowToUpdate["Cantidad"] = nuevaCantidadEnVenta;
                rowToUpdate["Subtotal"] = nuevaCantidadEnVenta * precioUnitario;
            }
            else
            {
                // Si el producto no está en la lista, agregamos una nueva fila
                DataRow newRow = dtProductosVenta.NewRow();
                newRow["IdProducto"] = idProducto;
                newRow["NombreProducto"] = nombreProducto;
                newRow["Cantidad"] = cantidad;
                newRow["PrecioUnitario"] = precioUnitario;
                newRow["Subtotal"] = cantidad * precioUnitario;
                dtProductosVenta.Rows.Add(newRow);
            }

            UpdateTotal(); // Actualizar el total a pagar de la venta
            numCantidadProducto.Value = 1; // Reiniciar la cantidad a 1 para la próxima adición
            cmbProductosAgregar.SelectedIndex = -1; 
        }

        private void VentasForm_Load(object sender, EventArgs e)
        {

        }
    }
}