﻿namespace Sistema_Ventas_Tienda_Ropas
{
    partial class VentasForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.txtIdVenta = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dateTimePickerFecha = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbClientes = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvProductosVenta = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnVolverMenu = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnGenerarVenta = new System.Windows.Forms.Button();
            this.txtTotalPagar = new System.Windows.Forms.TextBox();
            this.lblBuscarProducto = new System.Windows.Forms.Label();
            this.cmbProductosAgregar = new System.Windows.Forms.ComboBox();
            this.lblCantidad = new System.Windows.Forms.Label();
            this.numCantidadProducto = new System.Windows.Forms.NumericUpDown();
            this.btnAgregarProductoALista = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductosVenta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCantidadProducto)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(209, 7);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(208, 22);
            this.label6.TabIndex = 45;
            this.label6.Text = "Formulario de Ventas";
            // 
            // txtIdVenta
            // 
            this.txtIdVenta.Location = new System.Drawing.Point(191, 123);
            this.txtIdVenta.Margin = new System.Windows.Forms.Padding(2);
            this.txtIdVenta.Name = "txtIdVenta";
            this.txtIdVenta.Size = new System.Drawing.Size(274, 20);
            this.txtIdVenta.TabIndex = 47;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(53, 120);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 19);
            this.label3.TabIndex = 46;
            this.label3.Text = "ID Venta";
            // 
            // dateTimePickerFecha
            // 
            this.dateTimePickerFecha.Location = new System.Drawing.Point(192, 163);
            this.dateTimePickerFecha.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePickerFecha.Name = "dateTimePickerFecha";
            this.dateTimePickerFecha.Size = new System.Drawing.Size(274, 20);
            this.dateTimePickerFecha.TabIndex = 48;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(53, 163);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 19);
            this.label1.TabIndex = 49;
            this.label1.Text = "Fecha";
            // 
            // cmbClientes
            // 
            this.cmbClientes.FormattingEnabled = true;
            this.cmbClientes.Location = new System.Drawing.Point(192, 208);
            this.cmbClientes.Margin = new System.Windows.Forms.Padding(2);
            this.cmbClientes.Name = "cmbClientes";
            this.cmbClientes.Size = new System.Drawing.Size(274, 21);
            this.cmbClientes.TabIndex = 50;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(53, 208);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 19);
            this.label2.TabIndex = 51;
            this.label2.Text = "Clientes";
            // 
            // dgvProductosVenta
            // 
            this.dgvProductosVenta.BackgroundColor = System.Drawing.Color.White;
            this.dgvProductosVenta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductosVenta.Location = new System.Drawing.Point(11, 355);
            this.dgvProductosVenta.Margin = new System.Windows.Forms.Padding(2);
            this.dgvProductosVenta.Name = "dgvProductosVenta";
            this.dgvProductosVenta.RowHeadersWidth = 51;
            this.dgvProductosVenta.RowTemplate.Height = 24;
            this.dgvProductosVenta.Size = new System.Drawing.Size(590, 186);
            this.dgvProductosVenta.TabIndex = 52;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(266, 325);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 19);
            this.label4.TabIndex = 53;
            this.label4.Text = "Productos";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(41, 544);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 19);
            this.label5.TabIndex = 54;
            this.label5.Text = "Total a pagar";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.metodo_de_pago;
            this.pictureBox3.Location = new System.Drawing.Point(256, 32);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(99, 70);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 58;
            this.pictureBox3.TabStop = false;
            // 
            // btnVolverMenu
            // 
            this.btnVolverMenu.BackColor = System.Drawing.Color.Lavender;
            this.btnVolverMenu.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolverMenu.Image = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.Icons8_Windows_8_Industry_Return_16;
            this.btnVolverMenu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVolverMenu.Location = new System.Drawing.Point(213, 583);
            this.btnVolverMenu.Margin = new System.Windows.Forms.Padding(2);
            this.btnVolverMenu.Name = "btnVolverMenu";
            this.btnVolverMenu.Size = new System.Drawing.Size(159, 28);
            this.btnVolverMenu.TabIndex = 57;
            this.btnVolverMenu.Text = "Volver al menu";
            this.btnVolverMenu.UseVisualStyleBackColor = false;
            this.btnVolverMenu.Click += new System.EventHandler(this.btnVolverMenu_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.Lavender;
            this.btnCancelar.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelar.Image = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.Custom_Icon_Design_Pretty_Office_7_Bookmark_delete_16;
            this.btnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelar.Location = new System.Drawing.Point(396, 583);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(150, 28);
            this.btnCancelar.TabIndex = 56;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnGenerarVenta
            // 
            this.btnGenerarVenta.BackColor = System.Drawing.Color.Lavender;
            this.btnGenerarVenta.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerarVenta.Image = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.Custom_Icon_Design_Pretty_Office_7_Generate_keys_16;
            this.btnGenerarVenta.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGenerarVenta.Location = new System.Drawing.Point(30, 583);
            this.btnGenerarVenta.Margin = new System.Windows.Forms.Padding(2);
            this.btnGenerarVenta.Name = "btnGenerarVenta";
            this.btnGenerarVenta.Size = new System.Drawing.Size(150, 28);
            this.btnGenerarVenta.TabIndex = 55;
            this.btnGenerarVenta.Text = "Generar venta";
            this.btnGenerarVenta.UseVisualStyleBackColor = false;
            this.btnGenerarVenta.Click += new System.EventHandler(this.btnGenerarVenta_Click);
            // 
            // txtTotalPagar
            // 
            this.txtTotalPagar.Location = new System.Drawing.Point(191, 545);
            this.txtTotalPagar.Margin = new System.Windows.Forms.Padding(2);
            this.txtTotalPagar.Name = "txtTotalPagar";
            this.txtTotalPagar.Size = new System.Drawing.Size(274, 20);
            this.txtTotalPagar.TabIndex = 59;
            // 
            // lblBuscarProducto
            // 
            this.lblBuscarProducto.AutoSize = true;
            this.lblBuscarProducto.BackColor = System.Drawing.Color.Transparent;
            this.lblBuscarProducto.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBuscarProducto.Location = new System.Drawing.Point(41, 242);
            this.lblBuscarProducto.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBuscarProducto.Name = "lblBuscarProducto";
            this.lblBuscarProducto.Size = new System.Drawing.Size(139, 19);
            this.lblBuscarProducto.TabIndex = 60;
            this.lblBuscarProducto.Text = "Buscar Producto";
            // 
            // cmbProductosAgregar
            // 
            this.cmbProductosAgregar.FormattingEnabled = true;
            this.cmbProductosAgregar.Location = new System.Drawing.Point(191, 243);
            this.cmbProductosAgregar.Margin = new System.Windows.Forms.Padding(2);
            this.cmbProductosAgregar.Name = "cmbProductosAgregar";
            this.cmbProductosAgregar.Size = new System.Drawing.Size(274, 21);
            this.cmbProductosAgregar.TabIndex = 61;
            // 
            // lblCantidad
            // 
            this.lblCantidad.AutoSize = true;
            this.lblCantidad.BackColor = System.Drawing.Color.Transparent;
            this.lblCantidad.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCantidad.Location = new System.Drawing.Point(41, 285);
            this.lblCantidad.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCantidad.Name = "lblCantidad";
            this.lblCantidad.Size = new System.Drawing.Size(78, 19);
            this.lblCantidad.TabIndex = 62;
            this.lblCantidad.Text = "Cantidad";
            // 
            // numCantidadProducto
            // 
            this.numCantidadProducto.Location = new System.Drawing.Point(192, 287);
            this.numCantidadProducto.Name = "numCantidadProducto";
            this.numCantidadProducto.Size = new System.Drawing.Size(274, 20);
            this.numCantidadProducto.TabIndex = 63;
            // 
            // btnAgregarProductoALista
            // 
            this.btnAgregarProductoALista.BackColor = System.Drawing.Color.Lavender;
            this.btnAgregarProductoALista.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarProductoALista.Image = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.Custom_Icon_Design_Pretty_Office_7_Generate_keys_16;
            this.btnAgregarProductoALista.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAgregarProductoALista.Location = new System.Drawing.Point(492, 206);
            this.btnAgregarProductoALista.Margin = new System.Windows.Forms.Padding(2);
            this.btnAgregarProductoALista.Name = "btnAgregarProductoALista";
            this.btnAgregarProductoALista.Size = new System.Drawing.Size(118, 55);
            this.btnAgregarProductoALista.TabIndex = 64;
            this.btnAgregarProductoALista.Text = "Agregar Producto";
            this.btnAgregarProductoALista.UseVisualStyleBackColor = false;
            this.btnAgregarProductoALista.Click += new System.EventHandler(this.btnAgregarProductoALista_Click_1);
            // 
            // VentasForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.BackgroundImage = global::Sistema_Ventas_Tienda_Ropas.Properties.Resources.background_tela_login;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(635, 634);
            this.Controls.Add(this.btnAgregarProductoALista);
            this.Controls.Add(this.numCantidadProducto);
            this.Controls.Add(this.lblCantidad);
            this.Controls.Add(this.cmbProductosAgregar);
            this.Controls.Add(this.lblBuscarProducto);
            this.Controls.Add(this.txtTotalPagar);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.btnVolverMenu);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnGenerarVenta);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dgvProductosVenta);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbClientes);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePickerFecha);
            this.Controls.Add(this.txtIdVenta);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label6);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "VentasForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VentasForm";
            this.Load += new System.EventHandler(this.VentasForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductosVenta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCantidadProducto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtIdVenta;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dateTimePickerFecha;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbClientes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvProductosVenta;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnVolverMenu;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnGenerarVenta;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TextBox txtTotalPagar;
        private System.Windows.Forms.Label lblBuscarProducto;
        private System.Windows.Forms.ComboBox cmbProductosAgregar;
        private System.Windows.Forms.Label lblCantidad;
        private System.Windows.Forms.NumericUpDown numCantidadProducto;
        private System.Windows.Forms.Button btnAgregarProductoALista;
    }
}